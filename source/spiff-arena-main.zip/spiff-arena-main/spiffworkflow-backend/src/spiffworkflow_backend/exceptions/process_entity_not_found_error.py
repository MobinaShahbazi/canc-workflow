class ProcessEntityNotFoundError(Exception):
    pass

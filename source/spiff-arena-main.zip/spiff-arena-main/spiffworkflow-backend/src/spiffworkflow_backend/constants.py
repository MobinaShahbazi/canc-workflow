SPIFFWORKFLOW_BACKEND_SERIALIZER_VERSION = "5"

# so we can tell if a migration has changed or if there is a new one
SPIFFWORKFLOW_BACKEND_DATA_MIGRATION_CHECKSUM = {
    "version_1_3.py": "22636f5ffb8e6d56fa460d82f62a854c",
    "version_2.py": "d066710c58985e1db293931b01b00029",
    "version_3.py": "0e7154d0575c54b59011e3acedebe8b5",
    "version_4.py": "ed8a7a06d21fb3fbc7d1db5435c79058",
    "version_5.py": "249d9a406098d15b7bf549b51d68c85e",
}

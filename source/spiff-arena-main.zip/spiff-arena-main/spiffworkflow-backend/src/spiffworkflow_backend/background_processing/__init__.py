CELERY_TASK_PROCESS_INSTANCE_RUN = (
    "spiffworkflow_backend.background_processing.celery_tasks.process_instance_task.celery_task_process_instance_run"
)

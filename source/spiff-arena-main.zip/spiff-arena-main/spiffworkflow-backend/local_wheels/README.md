# Local Wheels

If you have any wheels you wish to test locally, copy them into this folder then run:

```
poetry add local_wheels/my.whl
```

Alternatively you can sideload it:

```
poetry run pip install local_wheels/*.whl
```

when you boot the backend.

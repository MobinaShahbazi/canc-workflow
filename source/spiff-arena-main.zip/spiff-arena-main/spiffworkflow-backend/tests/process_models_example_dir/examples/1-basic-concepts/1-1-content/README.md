# Creating Content
This section will explain how we combine **Markdown** and **Jinja** to make it easy to display content to participants in a workflow.

# Data

```{toctree}
:maxdepth: 1
:caption: Types of Data
task_data.md
data_objects.md
data_stores.md
```
